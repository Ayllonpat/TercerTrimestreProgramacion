package ejercicio;

public class ExcepcionCodigo extends Exception{
	
	ExcepcionCodigo(String msg){
		super(msg);
	}

}
