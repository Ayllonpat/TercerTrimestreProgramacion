package ejercicio;

public class ExcepcionNumeroNegativo extends Exception{
	
	ExcepcionNumeroNegativo(String msg){
		super(msg);
	}

}
