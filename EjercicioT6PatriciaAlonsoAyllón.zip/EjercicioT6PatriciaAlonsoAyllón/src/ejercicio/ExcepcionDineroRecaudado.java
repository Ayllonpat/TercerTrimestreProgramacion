package ejercicio;

public class ExcepcionDineroRecaudado extends Exception{
	
	ExcepcionDineroRecaudado(String msg){
		super(msg);
	}

}
